import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const MainLogin = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('student'); // 'student' or 'super_admin'
  const [step, setStep] = useState('login'); // 'login' or 'otp'
  
  // Form State
  const [applicationId, setApplicationId] = useState('');
  const [dob, setDob] = useState('');
  const [email, setEmail] = useState('');
  const [secretKey, setSecretKey] = useState('');
  
  // Security & OTP
  const [captchaText, setCaptchaText] = useState('');
  const [captchaInput, setCaptchaInput] = useState('');
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Generate authentic looking NTA CAPTCHA
  const generateCaptcha = () => {
    const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCaptchaText(result);
    setCaptchaInput('');
  };

  useEffect(() => {
    generateCaptcha();
    // Clear any existing session on login page load to prevent conflicts
    sessionStorage.clear();
  }, [activeTab]);

  const handleLoginSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (captchaInput.toUpperCase() !== captchaText.toUpperCase()) {
      setError('Invalid Security Pin. Please enter the pin exactly as shown.');
      generateCaptcha();
      return;
    }

    setLoading(true);
    try {
      const endpoint = activeTab === 'student' ? '/api/send-student-otp' : '/api/send-superadmin-otp';
      
      // CRITICAL ALIGNMENT: 
      // 1. We use .trim() to prevent accidental spaces.
      // 2. We map 'dob' to 'dateOfBirth' exactly as the backend expects.
      const payload = activeTab === 'student' 
        ? { 
            applicationId: applicationId.trim(), 
            dateOfBirth: dob 
          } 
        : { 
            email: email.trim(), 
            secretKey: secretKey.trim() 
          };

      const apiBaseUrl = import.meta.env.VITE_API_URL || 'https://hrta-production.up.railway.app';
      const response = await fetch(`${apiBaseUrl}${endpoint}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || data.message || 'Authentication failed. Please check your credentials.');
      }

      setStep('otp');
    } catch (err) {
      setError(err.message);
      generateCaptcha();
    } finally {
      setLoading(false);
    }
  };

  const handleOtpSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Send the exact identifier the backend used to store the OTP
      const identifier = activeTab === 'student' ? applicationId.trim() : email.trim();
      
      const apiBaseUrl = import.meta.env.VITE_API_URL || 'https://hrta-production.up.railway.app';
      const response = await fetch(`${apiBaseUrl}/api/verify-otp`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          identifier: identifier, 
          otp: otp.trim(),
          role: activeTab === 'student' ? 'student' : 'super_admin'
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || data.message || 'Invalid or Expired OTP.');
      }

      // 1. Store Secure Session Data
      sessionStorage.setItem('role', data.role);
      sessionStorage.setItem('userId', data.userId);
      if (data.userEmail) sessionStorage.setItem('userEmail', data.userEmail);

      // 2. Strict Role-Based Redirection
      if (data.role === 'super_admin' || data.role === 'admin') {
        navigate('/admin/dashboard', { replace: true });
      } else {
        navigate('/student/dashboard', { replace: true });
      }
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#f1f4f9] font-sans flex flex-col">
      
      {/* 1. GOVT HEADER */}
      <div className="bg-white border-b border-gray-300">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <img src="/assets/emblem.png" alt="Satyameva Jayate" className="h-16" />
            <div className="hidden md:block">
              <h1 className="text-[#005fa7] font-extrabold text-xl leading-tight uppercase tracking-wide">Harman Rathi Testing Agency</h1>
              <h2 className="text-gray-700 text-sm font-bold uppercase tracking-wider">Department of Higher Education</h2>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            <img src="/assets/nta_logo.png" alt="NTA" className="h-14" />
            <img src="/assets/amrit.png" alt="Amrit Mahotsav" className="h-12 hidden md:block" />
          </div>
        </div>
      </div>

      {/* 2. BLUE NAVIGATION */}
      <div className="bg-[#005fa7] text-white shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center">
          <div className="flex space-x-6 text-sm font-bold uppercase py-3">
            <span className="hover:text-yellow-400 cursor-pointer transition-colors">Home</span>
            <span className="hover:text-yellow-400 cursor-pointer transition-colors">Information Bulletin</span>
            <span className="hover:text-yellow-400 cursor-pointer transition-colors">Syllabus</span>
            <span className="hover:text-yellow-400 cursor-pointer transition-colors">Contact Us</span>
          </div>
        </div>
      </div>

      {/* 3. SCROLLING MARQUEE (NTA STYLE) */}
      <div className="bg-white border-b border-gray-300 py-1.5 px-4 shadow-sm flex">
        <div className="bg-[#e24a4a] text-white text-xs font-bold px-3 py-1 whitespace-nowrap uppercase">Latest News</div>
        <div className="overflow-hidden flex-1 relative flex items-center bg-gray-50">
          <div className="animate-marquee whitespace-nowrap text-sm font-semibold text-[#005fa7]">
            <span className="mx-4">🔔 Inviting Online Applications for HRTA Examination 2026</span>
            <span className="mx-4 text-gray-400">|</span>
            <span className="mx-4">🔔 Mock Test Portal is now live for registered candidates</span>
            <span className="mx-4 text-gray-400">|</span>
            <span className="mx-4">🔔 Ensure your profile photo meets the standard guidelines before appearing for tests.</span>
          </div>
        </div>
      </div>

      {/* 4. MAIN CONTENT AREA */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row gap-8 flex-1 w-full">
        
        {/* LEFT COLUMN - INSTRUCTIONS */}
        <div className="w-full md:w-7/12 space-y-6">
          <div className="bg-white rounded-md shadow-sm border border-gray-200">
            <div className="bg-[#005fa7] text-white px-5 py-3 rounded-t-md font-bold uppercase tracking-wide text-sm flex justify-between items-center">
              Steps to Apply Online
              <span className="bg-white text-[#005fa7] px-2 py-0.5 rounded text-xs">HRTA 2026</span>
            </div>
            <div className="p-6 space-y-5 text-sm text-gray-700 font-medium">
              <div className="flex gap-4 items-start">
                <div className="bg-orange-100 text-orange-600 font-black h-8 w-8 rounded-full flex items-center justify-center shrink-0 border border-orange-200">1</div>
                <div>
                  <h3 className="font-bold text-[#005fa7] mb-1">Apply for Online Registration</h3>
                  <p>Obtain your Application Number from the administrator. This unique HRTA ID will be used for all future logins and communications.</p>
                </div>
              </div>
              <div className="flex gap-4 items-start">
                <div className="bg-orange-100 text-orange-600 font-black h-8 w-8 rounded-full flex items-center justify-center shrink-0 border border-orange-200">2</div>
                <div>
                  <h3 className="font-bold text-[#005fa7] mb-1">Authenticate Profile</h3>
                  <p>Login using your Application Number and Date of Birth. Verify your identity using the One Time Password (OTP) sent to your registered email address.</p>
                </div>
              </div>
              <div className="flex gap-4 items-start">
                <div className="bg-orange-100 text-orange-600 font-black h-8 w-8 rounded-full flex items-center justify-center shrink-0 border border-orange-200">3</div>
                <div>
                  <h3 className="font-bold text-[#005fa7] mb-1">Access Examination Portal</h3>
                  <p>Once authenticated, access your candidate dashboard to view active tests, upcoming schedules, and download your official scorecards.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-yellow-50 border border-yellow-200 rounded p-4 text-sm text-yellow-800 font-semibold shadow-sm">
            <span className="font-black text-red-600">Note:</span> Please do not share your Application Number or OTP with anyone. The testing agency will never call you asking for these details.
          </div>
        </div>

        {/* RIGHT COLUMN - LOGIN BOX */}
        <div className="w-full md:w-5/12">
          <div className="bg-white shadow-xl rounded-md border border-gray-300 overflow-hidden">
            
            {/* Form Header */}
            <div className="bg-[#1f497d] text-white text-center py-3 font-bold text-lg border-b-4 border-orange-500 uppercase tracking-wide">
              Registered Candidates
            </div>

            {/* Form Tabs (Hidden during OTP) */}
            {step === 'login' && (
              <div className="flex border-b border-gray-200 bg-gray-50">
                <button
                  type="button"
                  className={`flex-1 py-3 text-xs font-bold uppercase transition-colors ${activeTab === 'student' ? 'bg-white text-[#005fa7] border-t-4 border-[#005fa7] shadow-[0_4px_0_0_white_inset]' : 'text-gray-500 hover:text-gray-800'}`}
                  onClick={() => { setActiveTab('student'); setError(''); }}
                >
                  Student Login
                </button>
                <button
                  type="button"
                  className={`flex-1 py-3 text-xs font-bold uppercase transition-colors ${activeTab === 'super_admin' ? 'bg-white text-[#005fa7] border-t-4 border-[#005fa7] shadow-[0_4px_0_0_white_inset]' : 'text-gray-500 hover:text-gray-800'}`}
                  onClick={() => { setActiveTab('super_admin'); setError(''); }}
                >
                  Admin Console
                </button>
              </div>
            )}

            <div className="p-6 md:p-8">
              {error && (
                <div className="mb-5 bg-red-50 border-l-4 border-red-500 p-3 text-red-700 text-sm font-bold flex items-start shadow-sm">
                  <svg className="w-5 h-5 mr-2 shrink-0" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd"></path></svg>
                  {error}
                </div>
              )}

              {/* STEP 1: CREDENTIALS */}
              {step === 'login' && (
                <form onSubmit={handleLoginSubmit} className="space-y-5">
                  {activeTab === 'student' ? (
                    <>
                      <div>
                        <label className="block text-sm font-bold text-gray-700 mb-1.5">Application No <span className="text-red-500">*</span></label>
                        <input
                          type="text" required
                          value={applicationId}
                          onChange={(e) => setApplicationId(e.target.value)}
                          className="w-full border border-gray-300 px-3.5 py-2.5 rounded-md focus:outline-none focus:ring-2 focus:ring-[#005fa7] focus:border-transparent bg-gray-50 text-gray-800 font-semibold uppercase transition-all"
                          placeholder="e.g. HRTA001"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-gray-750 mb-1.5">Password (Date of Birth) <span className="text-red-500">*</span></label>
                        <input
                          type="date" required
                          value={dob}
                          onChange={(e) => setDob(e.target.value)}
                          className="w-full border border-gray-300 px-3.5 py-2.5 rounded-md focus:outline-none focus:ring-2 focus:ring-[#005fa7] focus:border-transparent bg-gray-50 text-gray-800 font-semibold transition-all"
                        />
                      </div>
                    </>
                  ) : (
                    <>
                      <div>
                        <label className="block text-sm font-bold text-gray-750 mb-1.5">Administrator Email *</label>
                        <input
                          type="email" required
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full border border-gray-300 px-3.5 py-2.5 rounded-md focus:outline-none focus:ring-2 focus:ring-[#005fa7] focus:border-transparent bg-gray-50 font-semibold transition-all"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-bold text-gray-750 mb-1.5">Super Admin Secret Key *</label>
                        <input
                          type="password" required
                          value={secretKey}
                          onChange={(e) => setSecretKey(e.target.value)}
                          className="w-full border border-gray-300 px-3.5 py-2.5 rounded-md focus:outline-none focus:ring-2 focus:ring-[#005fa7] focus:border-transparent bg-gray-50 font-semibold transition-all"
                        />
                      </div>
                    </>
                  )}

                  {/* Captcha Section */}
                  <div className="pt-2">
                    <label className="block text-sm font-bold text-gray-750 mb-1.5">Security Pin *</label>
                    <div className="flex items-center space-x-3 mb-3">
                      <div className="bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPgo8cmVjdCB3aWR0aD0iNCIgaGVpZ2h0PSI0IiBmaWxsPSIjZmZmIj48L3JlY3Q+CjxyZWN0IHdpZHRoPSIxIiBoZWlnaHQ9IjEiIGZpbGw9IiNjY2MiPjwvcmVjdD4KPC9zdmc+')] border border-gray-300 px-6 py-2.5 font-mono text-xl tracking-[0.3em] font-black text-[#005fa7] rounded-md select-none line-through decoration-gray-400 decoration-2 italic shadow-inner w-3/4 text-center">
                        {captchaText}
                      </div>
                      <button type="button" onClick={generateCaptcha} className="w-1/4 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2.5 rounded-md transition flex items-center justify-center border border-gray-300 cursor-pointer shadow-sm" title="Refresh PIN">
                        <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                      </button>
                    </div>
                    <input
                      type="text" required
                      value={captchaInput}
                      onChange={(e) => setCaptchaInput(e.target.value)}
                      className="w-full border border-gray-300 px-3.5 py-2.5 rounded-md focus:outline-none focus:ring-2 focus:ring-[#005fa7] focus:border-transparent bg-white font-semibold transition-all"
                      placeholder="Enter Security Pin shown above"
                    />
                  </div>

                  <button
                    type="submit" disabled={loading}
                    className="w-full bg-[#005fa7] hover:bg-[#004b87] text-white py-3 rounded-md font-bold text-base shadow-md transition-colors flex justify-center items-center uppercase tracking-wide mt-4 disabled:opacity-70 cursor-pointer"
                  >
                    {loading ? (
                      <svg className="animate-spin h-5 w-5 mr-3 text-white" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                    ) : "Login"}
                  </button>
                </form>
              )}

              {/* STEP 2: OTP VERIFICATION */}
              {step === 'otp' && (
                <form onSubmit={handleOtpSubmit} className="space-y-6">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4 border-4 border-white shadow-sm">
                      <svg className="w-8 h-8 text-[#005fa7]" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                    </div>
                    <h3 className="font-bold text-lg text-gray-800">Two-Step Verification</h3>
                    <p className="text-sm text-gray-600 mt-2 font-medium leading-relaxed">
                      Please enter the 6-digit OTP sent to your registered email address to complete verification.
                    </p>
                  </div>

                  <div>
                    <input
                      type="text" required maxLength="6"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, ''))}
                      className="w-full border-2 border-gray-400 px-4 py-4 text-center text-3xl font-black tracking-[0.7em] rounded bg-gray-50 focus:outline-none focus:border-[#005fa7] focus:bg-white transition-colors"
                      placeholder="••••••"
                    />
                  </div>

                  <div className="flex space-x-3 pt-2">
                    <button
                      type="button"
                      onClick={() => { setStep('login'); setOtp(''); generateCaptcha(); }}
                      className="w-1/3 bg-gray-200 text-gray-700 py-3 rounded-sm font-bold hover:bg-gray-300 transition-colors border border-gray-300 shadow-sm"
                    >
                      Back
                    </button>
                    <button
                      type="submit"
                      disabled={loading || otp.length !== 6}
                      className="w-2/3 bg-[#005fa7] text-white py-3 rounded-sm font-bold hover:bg-[#004b87] shadow-md transition-colors flex justify-center items-center uppercase disabled:opacity-60 disabled:cursor-not-allowed"
                    >
                      {loading ? 'Verifying...' : 'Verify & Proceed'}
                    </button>
                  </div>
                </form>
              )}
            </div>
            
            <div className="bg-gray-100 py-3 px-6 border-t border-gray-300 flex justify-between items-center text-xs font-bold text-gray-600">
               <span>Forgot Password? Contact Admin.</span>
               <a href="#" className="text-[#005fa7] hover:underline">Help Desk</a>
            </div>
          </div>
        </div>
      </div>
      
      {/* 5. FOOTER */}
      <footer className="bg-gray-800 text-gray-400 border-t-4 border-[#005fa7] mt-auto py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center text-xs font-medium">
          <p>© {new Date().getFullYear()} HARMAN RATHI TESTING AGENCY. All Rights Reserved.</p>
          <div className="flex space-x-6 mt-3 md:mt-0">
            <span className="hover:text-white cursor-pointer transition-colors">Disclaimer</span>
            <span className="hover:text-white cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer transition-colors">Terms of Use</span>
          </div>
        </div>
      </footer>
      
      <style>{`
        @keyframes marquee {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
        .animate-marquee {
          display: inline-block;
          animation: marquee 25s linear infinite;
        }
        .animate-marquee:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
};

export default MainLogin;
