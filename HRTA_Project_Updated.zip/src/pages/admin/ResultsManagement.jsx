import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '@/lib/supabase'
import { toast } from 'sonner'
import { Eye, CheckCircle, Clock, Filter, Search, RotateCcw, ShieldAlert, ShieldCheck } from 'lucide-react'

export default function ResultsManagement() {
  const [submissions, setSubmissions] = useState([])
  const [filteredSubmissions, setFilteredSubmissions] = useState([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')

  useEffect(() => {
    loadSubmissions()
  }, [])

  useEffect(() => {
    filterSubmissions()
  }, [searchQuery, statusFilter, submissions])

  const loadSubmissions = async () => {
    const { data, error } = await supabase
      .from('exam_results')
      .select('*, exams(title, subject), students(full_name, application_id)')
      .order('submitted_at', { ascending: false })

    if (!error) {
      setSubmissions(data || [])
      setFilteredSubmissions(data || [])
    }
    setLoading(false)
  }

  const filterSubmissions = () => {
    let filtered = [...submissions]

    if (statusFilter !== 'all') {
      filtered = filtered.filter(s => s.status === statusFilter)
    }

    if (searchQuery) {
      filtered = filtered.filter(s => {
        const name = s.students?.full_name || s.student_name || '';
        const appId = s.students?.application_id || s.application_id || '';
        return name.toLowerCase().includes(searchQuery.toLowerCase()) ||
               appId.toLowerCase().includes(searchQuery.toLowerCase());
      })
    }

    setFilteredSubmissions(filtered)
  }

  const handleResetAttempt = async (id, studentName, examTitle) => {
    if (!window.confirm(`Are you sure you want to RESET the attempt for ${studentName} on "${examTitle}"?\n\nThis will delete their exam submission permanently and let them take the test again.`)) {
      return
    }
    try {
      const { error } = await supabase
        .from('exam_results')
        .delete()
        .eq('id', id)
      if (error) throw error
      toast.success("Attempt reset successfully. Candidate can now retake this exam.")
      loadSubmissions()
    } catch (err) {
      console.error(err)
      toast.error("Failed to reset attempt.")
    }
  }

  const handleToggleAccess = async (id, currentStatus, studentName, examTitle) => {
    const isBlocking = currentStatus !== 'blocked'
    const confirmMessage = isBlocking
      ? `Are you sure you want to REVOKE access for ${studentName} on "${examTitle}"?\n\nThey will not be able to view their scorecard or attempt it again.`
      : `Are you sure you want to RESTORE access for ${studentName} on "${examTitle}"?`

    if (!window.confirm(confirmMessage)) {
      return
    }

    try {
      const newStatus = isBlocking ? 'blocked' : 'submitted'
      const { error } = await supabase
        .from('exam_results')
        .update({ status: newStatus })
        .eq('id', id)

      if (error) throw error
      toast.success(isBlocking ? "Access revoked successfully." : "Access restored successfully.")
      loadSubmissions()
    } catch (err) {
      console.error(err)
      toast.error("Failed to update access status.")
    }
  }

  const getStatusBadge = (status) => {
    const config = {
      submitted: { color: 'bg-yellow-500/20 text-yellow-400', icon: Clock },
      reviewed: { color: 'bg-blue-500/20 text-blue-400', icon: CheckCircle },
      published: { color: 'bg-green-500/20 text-green-400', icon: CheckCircle },
      blocked: { color: 'bg-red-500/20 text-red-400', icon: ShieldAlert },
    }
    const StatusIcon = config[status]?.icon || Clock
    return (
      <span className={`px-2 py-1 rounded-full text-xs flex items-center gap-1 w-fit ${config[status]?.color || 'bg-gray-500/20 text-gray-400'}`}>
        <StatusIcon className="w-3 h-3" /> {status === 'blocked' ? 'Revoked' : status}
      </span>
    )
  }

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold">Results Management</h1>
        <p className="text-sm text-muted-foreground">Review and manage student exam submissions</p>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search by student name or Application ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 rounded-lg bg-secondary/30 border border-border/50 focus:border-primary focus:outline-none"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="px-4 py-2 rounded-lg bg-secondary/30 border border-border/50 focus:border-primary focus:outline-none"
        >
          <option value="all">All Status</option>
          <option value="submitted">Pending Review</option>
          <option value="reviewed">Reviewed</option>
          <option value="published">Published</option>
          <option value="blocked">Access Revoked</option>
        </select>
      </div>

      {/* Submissions Table */}
      <div className="glass-card rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="border-b border-border/50">
              <tr>
                <th className="text-left p-4 text-xs font-medium text-muted-foreground">Student</th>
                <th className="text-left p-4 text-xs font-medium text-muted-foreground">Exam</th>
                <th className="text-left p-4 text-xs font-medium text-muted-foreground">Score</th>
                <th className="text-left p-4 text-xs font-medium text-muted-foreground">Submitted</th>
                <th className="text-left p-4 text-xs font-medium text-muted-foreground">Status</th>
                <th className="text-left p-4 text-xs font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan="6" className="text-center py-8 text-muted-foreground">Loading...</td></tr>
              ) : filteredSubmissions.length === 0 ? (
                <tr><td colSpan="6" className="text-center py-8 text-muted-foreground">No submissions found</td></tr>
              ) : (
                filteredSubmissions.map((sub) => {
                  const studentName = sub.students?.full_name || sub.student_name || 'Student';
                  const appId = sub.students?.application_id || sub.application_id || 'N/A';
                  const examTitle = sub.exams?.title || 'Exam';

                  return (
                    <tr key={sub.id} className="border-b border-border/30 hover:bg-secondary/20">
                      <td className="p-4">
                        <p className="text-sm font-medium">{studentName}</p>
                        <p className="text-xs text-muted-foreground font-mono">{appId}</p>
                      </td>
                      <td className="p-4">
                        <p className="text-sm">{examTitle}</p>
                        <p className="text-xs text-muted-foreground">{sub.exams?.subject}</p>
                      </td>
                      <td className="p-4">
                        {sub.total_score !== null ? (
                          <p className="text-sm font-medium">{sub.total_score}/{sub.total_marks} ({sub.percentage}%)</p>
                        ) : (
                          <p className="text-sm text-muted-foreground">Not evaluated</p>
                        )}
                      </td>
                      <td className="p-4 text-sm">
                        {sub.submitted_at ? new Date(sub.submitted_at).toLocaleDateString() : '-'}
                      </td>
                      <td className="p-4">
                        {getStatusBadge(sub.status)}
                      </td>
                      <td className="p-4 flex items-center gap-2">
                        <Link to={`/admin/results/${sub.id}`}>
                          <button className="p-2 rounded-lg hover:bg-primary/10 transition-colors" title="Review Submission">
                            <Eye className="w-4 h-4 text-primary" />
                          </button>
                        </Link>
                        
                        <button 
                          onClick={() => handleResetAttempt(sub.id, studentName, examTitle)}
                          className="p-2 rounded-lg hover:bg-red-500/10 transition-colors" 
                          title="Reset Attempt (Assign Again)"
                        >
                          <RotateCcw className="w-4 h-4 text-red-500" />
                        </button>
                        
                        {sub.status === 'blocked' ? (
                          <button 
                            onClick={() => handleToggleAccess(sub.id, sub.status, studentName, examTitle)}
                            className="p-2 rounded-lg hover:bg-green-500/10 transition-colors" 
                            title="Restore Access"
                          >
                            <ShieldCheck className="w-4 h-4 text-green-500" />
                          </button>
                        ) : (
                          <button 
                            onClick={() => handleToggleAccess(sub.id, sub.status, studentName, examTitle)}
                            className="p-2 rounded-lg hover:bg-amber-500/10 transition-colors" 
                            title="Revoke Access (Block)"
                          >
                            <ShieldAlert className="w-4 h-4 text-amber-500" />
                          </button>
                        )}
                      </td>
                    </tr>
                  )
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
