import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';

const StudyMaterials = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [materials, setMaterials] = useState([]);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    subject: 'Physics',
    google_drive_link: ''
  });

  useEffect(() => {
    fetchMaterials();
  }, [navigate]);

  const fetchMaterials = async () => {
    try {
      const role = sessionStorage.getItem('role');
      if (role !== 'super_admin') {
        navigate('/');
        return;
      }

      const { data, error: fetchErr } = await supabase
        .from('study_materials')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchErr) throw fetchErr;
      setMaterials(data || []);
    } catch (err) {
      console.error("Error fetching materials:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');

    // Basic URL validation
    if (!formData.google_drive_link.includes('drive.google.com') && !formData.google_drive_link.includes('docs.google.com')) {
      setError("Please provide a valid Google Drive link.");
      setSaving(false);
      return;
    }

    try {
      // Build the exact payload that matches our SQL schema
      const newMaterial = {
        title: formData.title.trim(),
        description: formData.description.trim(),
        subject: formData.subject,
        google_drive_link: formData.google_drive_link.trim()
      };

      const { data, error: insertError } = await supabase
        .from('study_materials')
        .insert([newMaterial])
        .select()
        .single();

      if (insertError) {
        console.error("Insert Error Details:", insertError);
        throw insertError;
      }

      // Update UI and reset form
      setMaterials([data, ...materials]);
      setFormData({ title: '', description: '', subject: 'Physics', google_drive_link: '' });
      alert("Study Material Link Added Successfully!");

    } catch (err) {
      // Catch schema cache errors explicitly
      if (err.message && err.message.includes('schema cache')) {
        setError('DATABASE ERROR: The study_materials table does not exist yet. Please run the SQL command provided earlier in your Supabase SQL Editor.');
      } else {
        setError(err.message || 'Failed to add material. Please check your connection.');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id, title) => {
    if (!window.confirm(`Are you sure you want to delete "${title}"?`)) return;

    try {
      const { error: deleteErr } = await supabase.from('study_materials').delete().eq('id', id);
      if (deleteErr) throw deleteErr;
      setMaterials(materials.filter(m => m.id !== id));
    } catch (err) {
      alert("Failed to delete material.");
    }
  };

  if (loading) return <div className="p-8 text-[#005fa7] font-bold">Loading Materials Database...</div>;

  return (
    <div className="min-h-screen bg-gray-50 font-sans pb-12">
      {/* Header */}
      <div className="bg-white border-b border-gray-300 shadow-sm px-8 py-6 mb-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <Link to="/admin/dashboard" className="text-[#005fa7] hover:underline text-sm font-semibold mb-2 inline-block">&larr; Back to Dashboard</Link>
            <h1 className="text-2xl font-black text-[#005fa7] tracking-tight">Study Materials Management</h1>
            <p className="text-sm font-bold text-gray-500 mt-1">Share Google Drive resources, notes, and formula sheets with candidates.</p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* LEFT COLUMN: Add New Material Form */}
        <div className="lg:col-span-1 bg-white rounded shadow-sm border border-gray-300 overflow-hidden h-fit">
          <div className="bg-[#005fa7] text-white px-5 py-3 font-bold text-sm uppercase tracking-wide">
            Add New Resource
          </div>
          
          <form onSubmit={handleSubmit} className="p-5 space-y-5">
            {error && (
              <div className="bg-red-50 text-red-700 p-3 rounded text-sm font-bold border border-red-200">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Resource Title *</label>
              <input 
                type="text" required
                value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})}
                placeholder="e.g., Kinematics Formula Sheet"
                className="w-full px-3 py-2 border border-gray-300 rounded focus:border-[#005fa7] outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Subject *</label>
              <select 
                value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded focus:border-[#005fa7] outline-none bg-white"
              >
                <option value="Physics">Physics</option>
                <option value="Chemistry">Chemistry</option>
                <option value="Mathematics">Mathematics</option>
                <option value="General Aptitude">General Aptitude</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Google Drive Link *</label>
              <input 
                type="url" required
                value={formData.google_drive_link} onChange={e => setFormData({...formData, google_drive_link: e.target.value})}
                placeholder="https://drive.google.com/..."
                className="w-full px-3 py-2 border border-gray-300 rounded focus:border-[#005fa7] outline-none"
              />
              <p className="text-xs text-gray-500 mt-1 font-semibold">Ensure link sharing is set to "Anyone with the link".</p>
            </div>

            <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Short Description (Optional)</label>
              <textarea 
                rows="2"
                value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})}
                placeholder="Briefly describe the contents..."
                className="w-full px-3 py-2 border border-gray-300 rounded focus:border-[#005fa7] outline-none"
              ></textarea>
            </div>

            <button 
              type="submit" disabled={saving}
              className="w-full bg-[#28a745] text-white py-2.5 rounded font-bold hover:bg-[#218838] transition shadow disabled:opacity-50 uppercase tracking-wide text-sm"
            >
              {saving ? 'Publishing...' : 'Publish Resource'}
            </button>
          </form>
        </div>

        {/* RIGHT COLUMN: List of Existing Materials */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-4 rounded shadow-sm border border-gray-300 flex justify-between items-center">
            <h2 className="font-bold text-gray-800 uppercase text-sm tracking-wide">Published Resources</h2>
            <span className="bg-[#005fa7] text-white px-3 py-1 rounded-full text-xs font-bold">{materials.length} Active</span>
          </div>

          {materials.length === 0 ? (
            <div className="bg-white p-8 text-center text-gray-500 font-bold border border-gray-300 rounded shadow-sm">
              No study materials have been published yet.
            </div>
          ) : (
            materials.map((mat) => (
              <div key={mat.id} className="bg-white p-5 rounded shadow-sm border border-gray-300 flex flex-col sm:flex-row justify-between sm:items-center gap-4 hover:border-[#005fa7] transition-colors">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <span className="bg-gray-100 text-[#005fa7] px-2 py-0.5 rounded text-xs font-bold border border-gray-200">{mat.subject}</span>
                    <span className="text-xs text-gray-400 font-semibold">{new Date(mat.created_at).toLocaleDateString()}</span>
                  </div>
                  <h3 className="font-black text-gray-800 text-lg">{mat.title}</h3>
                  {mat.description && <p className="text-sm text-gray-600 mt-1">{mat.description}</p>}
                </div>
                
                <div className="flex items-center gap-3">
                  <a 
                    href={mat.google_drive_link} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-blue-50 text-[#005fa7] border border-[#005fa7] hover:bg-[#005fa7] hover:text-white px-4 py-2 rounded text-sm font-bold transition flex items-center"
                  >
                    <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14H9v-2h2v2zm0-4H9V7h2v5z"/></svg>
                    Test Link
                  </a>
                  <button 
                    onClick={() => handleDelete(mat.id, mat.title)}
                    className="bg-red-50 text-red-600 border border-red-200 hover:bg-red-600 hover:text-white px-4 py-2 rounded text-sm font-bold transition"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default StudyMaterials;
