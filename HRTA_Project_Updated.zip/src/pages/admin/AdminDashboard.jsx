import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  
  const [stats, setStats] = useState({
    totalStudents: 0,
    activeStudents: 0,
    totalExams: 0,
    publishedExams: 0,
    pendingSubmissions: 0,
    totalSubmissions: 0
  });

  const [pendingResults, setPendingResults] = useState([]);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const role = sessionStorage.getItem('role');
        if (role !== 'super_admin') {
          navigate('/');
          return;
        }

        // 1. Fetch Students Stats
        const { count: totalStudents, error: studentErr } = await supabase
          .from('students')
          .select('*', { count: 'exact', head: true });
          
        const { count: activeStudents, error: activeStudentErr } = await supabase
          .from('students')
          .select('*', { count: 'exact', head: true })
          .eq('status', 'active');

        // 2. Fetch Exams Stats
        const { count: totalExams, error: examErr } = await supabase
          .from('exams')
          .select('*', { count: 'exact', head: true });
          
        const { count: publishedExams, error: pubExamErr } = await supabase
          .from('exams')
          .select('*', { count: 'exact', head: true })
          .eq('status', 'published');

        // 3. Fetch Submissions Stats
        const { count: totalSub, error: subErr } = await supabase
          .from('exam_results')
          .select('*', { count: 'exact', head: true });
          
        const { count: pendingSub, error: pendSubErr } = await supabase
          .from('exam_results')
          .select('*', { count: 'exact', head: true })
          .eq('status', 'submitted');

        // 4. Fetch top 5 pending submissions for quick review
        const { data: recentPending, error: recentErr } = await supabase
          .from('exam_results')
          .select(`
            id,
            submitted_at,
            students ( full_name, application_id ),
            exams ( title )
          `)
          .eq('status', 'submitted')
          .order('submitted_at', { ascending: false })
          .limit(5);

        if (studentErr || examErr || subErr || recentErr) {
          throw new Error("Failed to load dashboard statistics.");
        }

        setStats({
          totalStudents: totalStudents || 0,
          activeStudents: activeStudents || 0,
          totalExams: totalExams || 0,
          publishedExams: publishedExams || 0,
          totalSubmissions: totalSub || 0,
          pendingSubmissions: pendingSub || 0
        });

        setPendingResults(recentPending || []);

      } catch (err) {
        console.error("Dashboard Error:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, [navigate]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center font-sans">
        <div className="text-[#005fa7] font-bold text-xl flex items-center">
          <svg className="animate-spin h-6 w-6 mr-3" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Loading Admin Command Center...
        </div>
      </div>
    );
  }

  // Helper component for stat cards
  const StatCard = ({ title, value, subtext, colorClass, iconPath }) => (
    <div className={`bg-white rounded shadow-sm border border-gray-200 p-6 flex items-center justify-between border-l-4 ${colorClass}`}>
      <div>
        <p className="text-sm font-bold text-gray-500 uppercase tracking-wide">{title}</p>
        <p className="text-3xl font-black text-gray-800 mt-1">{value}</p>
        {subtext && <p className="text-xs font-semibold text-gray-400 mt-1">{subtext}</p>}
      </div>
      <div className="w-12 h-12 rounded-full bg-gray-50 flex items-center justify-center border border-gray-200">
        <svg className="w-6 h-6 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={iconPath}></path>
        </svg>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 font-sans pb-12">
      
      {/* Header */}
      <div className="bg-white border-b border-gray-300 shadow-sm px-8 py-6 mb-8">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-black text-[#005fa7] tracking-tight">Super Admin Command Center</h1>
            <p className="text-sm font-bold text-gray-500 mt-1">Manage examinations, evaluate submissions, and oversee candidates.</p>
          </div>
          <div className="flex space-x-3">
            <Link to="/admin/exams/create">
              <button className="bg-[#28a745] hover:bg-[#218838] text-white px-5 py-2.5 rounded font-bold shadow-sm transition-colors text-sm uppercase tracking-wide">
                + Create New Exam
              </button>
            </Link>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Stat Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard 
            title="Total Candidates" 
            value={stats.totalStudents} 
            subtext={`${stats.activeStudents} Active Accounts`}
            colorClass="border-l-blue-500"
            iconPath="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"
          />
          <StatCard 
            title="Total Exams" 
            value={stats.totalExams} 
            subtext={`${stats.publishedExams} Published`}
            colorClass="border-l-indigo-500"
            iconPath="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
          />
          <StatCard 
            title="Pending Evaluations" 
            value={stats.pendingSubmissions} 
            subtext="Requires Manual Review"
            colorClass="border-l-yellow-500"
            iconPath="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
          />
          <StatCard 
            title="Total Submissions" 
            value={stats.totalSubmissions} 
            subtext="All time exam attempts"
            colorClass="border-l-green-500"
            iconPath="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
          />
        </div>

        {/* Two Column Layout for Action Areas */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Action Area - Pending Submissions */}
          <div className="lg:col-span-2 bg-white rounded shadow-sm border border-gray-300 overflow-hidden">
            <div className="bg-[#005fa7] text-white px-6 py-4 flex justify-between items-center">
              <h2 className="font-bold uppercase tracking-wide text-sm">Action Required: Pending Evaluations</h2>
              <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">{stats.pendingSubmissions} Pending</span>
            </div>
            
            <div className="p-0">
              {pendingResults.length === 0 ? (
                <div className="p-8 text-center text-gray-500 font-bold border-b border-gray-200">
                  <p className="text-lg text-green-600 mb-2">🎉 All Caught Up!</p>
                  No pending exam submissions require manual evaluation right now.
                </div>
              ) : (
                <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-xs font-bold text-gray-500 uppercase">Candidate</th>
                      <th className="px-6 py-3 text-xs font-bold text-gray-500 uppercase">Exam Title</th>
                      <th className="px-6 py-3 text-xs font-bold text-gray-500 uppercase">Submitted At</th>
                      <th className="px-6 py-3 text-xs font-bold text-gray-500 uppercase text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {pendingResults.map((result) => (
                      <tr key={result.id} className="hover:bg-blue-50 transition-colors">
                        <td className="px-6 py-4">
                          <p className="text-sm font-bold text-[#005fa7]">{result.students?.full_name}</p>
                          <p className="text-xs text-gray-500 font-semibold">{result.students?.application_id}</p>
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm font-bold text-gray-800">{result.exams?.title}</p>
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm text-gray-600 font-medium">
                            {new Date(result.submitted_at).toLocaleDateString()}
                          </p>
                          <p className="text-xs text-gray-400">
                            {new Date(result.submitted_at).toLocaleTimeString()}
                          </p>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <Link to={`/admin/results/${result.id}`}>
                            <button className="bg-orange-500 hover:bg-orange-600 text-white px-4 py-1.5 rounded text-xs font-bold uppercase shadow transition-colors">
                              Review & Publish
                            </button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
              {stats.pendingSubmissions > 5 && (
                <div className="bg-gray-50 px-6 py-3 text-center border-t border-gray-200">
                  <Link to="/admin/results" className="text-sm font-bold text-[#005fa7] hover:underline">
                    View All {stats.pendingSubmissions} Pending Submissions &rarr;
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar Area - Quick Links & System Health */}
          <div className="space-y-6">
            
            {/* Quick Actions */}
            <div className="bg-white rounded shadow-sm border border-gray-300">
              <div className="bg-gray-100 px-5 py-3 border-b border-gray-300">
                <h2 className="font-bold text-gray-700 uppercase tracking-wide text-xs">Administrative Tools</h2>
              </div>
              <div className="p-3 space-y-2">
                <Link to="/admin/students" className="flex items-center p-3 text-sm font-bold text-gray-700 hover:bg-blue-50 hover:text-[#005fa7] rounded transition-colors group">
                  <span className="bg-gray-200 group-hover:bg-[#005fa7] group-hover:text-white p-2 rounded mr-3 transition-colors">👤</span>
                  Manage Candidates Database
                </Link>
                <Link to="/admin/exams" className="flex items-center p-3 text-sm font-bold text-gray-700 hover:bg-blue-50 hover:text-[#005fa7] rounded transition-colors group">
                  <span className="bg-gray-200 group-hover:bg-[#005fa7] group-hover:text-white p-2 rounded mr-3 transition-colors">📝</span>
                  Manage Examination Roster
                </Link>
                <Link to="/admin/materials" className="flex items-center p-3 text-sm font-bold text-gray-700 hover:bg-blue-50 hover:text-[#005fa7] rounded transition-colors group">
                  <span className="bg-gray-200 group-hover:bg-[#005fa7] group-hover:text-white p-2 rounded mr-3 transition-colors">📚</span>
                  Upload Study Materials (G-Drive)
                </Link>
                <Link to="/admin/settings" className="flex items-center p-3 text-sm font-bold text-gray-700 hover:bg-blue-50 hover:text-[#005fa7] rounded transition-colors group">
                  <span className="bg-gray-200 group-hover:bg-[#005fa7] group-hover:text-white p-2 rounded mr-3 transition-colors">⚙️</span>
                  Platform Settings & Limits
                </Link>
              </div>
            </div>

            {/* System Status */}
            <div className="bg-white rounded shadow-sm border border-gray-300">
              <div className="bg-gray-100 px-5 py-3 border-b border-gray-300">
                <h2 className="font-bold text-gray-700 uppercase tracking-wide text-xs">System Health</h2>
              </div>
              <div className="p-5 space-y-4">
                <div>
                  <div className="flex justify-between text-xs font-bold text-gray-600 mb-1">
                    <span>Database Status (Supabase)</span>
                    <span className="text-green-600">ONLINE</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5"><div className="bg-green-500 h-1.5 rounded-full w-full"></div></div>
                </div>
                <div>
                  <div className="flex justify-between text-xs font-bold text-gray-600 mb-1">
                    <span>Email OTP Service (Resend)</span>
                    <span className="text-green-600">ACTIVE</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5"><div className="bg-green-500 h-1.5 rounded-full w-full"></div></div>
                </div>
                <div>
                  <div className="flex justify-between text-xs font-bold text-gray-600 mb-1">
                    <span>Image Storage (Cloudinary)</span>
                    <span className="text-green-600">HEALTHY</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-1.5"><div className="bg-green-500 h-1.5 rounded-full w-full"></div></div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
