import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { supabase } from '../../lib/supabase';

const ReviewSubmission = () => {
  const { submissionId } = useParams();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [publishing, setPublishing] = useState(false);
  const [error, setError] = useState('');
  
  const [submission, setSubmission] = useState(null);
  const [student, setStudent] = useState(null);
  const [exam, setExam] = useState(null);
  const [questions, setQuestions] = useState([]);
  
  // Track manual overrides: { questionId: numericMark }
  const [markOverrides, setMarkOverrides] = useState({});

  useEffect(() => {
    const fetchSubmissionData = async () => {
      try {
        const role = sessionStorage.getItem('role');
        if (role !== 'super_admin') {
          navigate('/');
          return;
        }

        // 1. Fetch Submission
        const { data: subData, error: subErr } = await supabase
          .from('exam_results')
          .select('*')
          .eq('id', submissionId)
          .single();

        if (subErr) throw subErr;

        // 2. Fetch related entities concurrently
        const [studentRes, examRes, questionsRes] = await Promise.all([
          supabase.from('students').select('*').eq('id', subData.student_id).single(),
          supabase.from('exams').select('*').eq('id', subData.exam_id).single(),
          supabase.from('questions').select('*').eq('exam_id', subData.exam_id).order('order_index', { ascending: true })
        ]);

        if (studentRes.error) throw studentRes.error;
        if (examRes.error) throw examRes.error;
        if (questionsRes.error) throw questionsRes.error;

        setSubmission(subData);
        setStudent(studentRes.data);
        setExam(examRes.data);
        setQuestions(questionsRes.data);
        
        // Initialize existing overrides if any
        if (subData.marks_adjustments) {
          setMarkOverrides(subData.marks_adjustments);
        }

      } catch (err) {
        console.error("Error fetching submission:", err);
        setError("Failed to load submission data.");
      } finally {
        setLoading(false);
      }
    };

    fetchSubmissionData();
  }, [submissionId, navigate]);

  // Helper to calculate auto-marks for a single question based on provisional hardcoded logic
  // (In a full engine, this calls the EvaluationService)
  // Upgraded professional auto-marks calculator engine
  const calculateAutoMark = (question) => {
    const studentAnswer = submission?.answers?.[question.id];
    
    // Unattempted
    if (
      studentAnswer === undefined || 
      studentAnswer === null || 
      studentAnswer === '' || 
      (Array.isArray(studentAnswer) && studentAnswer.length === 0)
    ) {
      return 0;
    }

    const qType = question.question_type || question.type;
    const posMarks = parseFloat(question.positive_marks) || parseFloat(exam?.correct_marks) || 4;
    const negMarks = parseFloat(question.negative_marks) || parseFloat(exam?.negative_marks) || 0;
    const policy = question.scoring_policy || 'exact_match';

    // Parse correct answers
    let correctList = [];
    try {
      correctList = JSON.parse(question.correct_answer);
      if (!Array.isArray(correctList)) {
        correctList = [correctList];
      }
    } catch (e) {
      if (question.correct_answer) {
        correctList = [question.correct_answer];
      }
    }
    correctList = correctList.map(item => String(item).trim().toLowerCase());

    // Parse student answers
    let selectedList = [];
    if (Array.isArray(studentAnswer)) {
      selectedList = studentAnswer.map(item => String(item).trim().toLowerCase());
    } else {
      selectedList = [String(studentAnswer).trim().toLowerCase()];
    }

    // 1. Numerical evaluation
    if (qType === 'numerical_integer' || qType === 'numerical_decimal') {
      const sNum = parseFloat(studentAnswer);
      const cNum = parseFloat(question.correct_answer);
      if (isNaN(sNum) || isNaN(cNum)) return -negMarks;
      
      if (qType === 'numerical_integer') {
        return Math.round(sNum) === Math.round(cNum) ? posMarks : -negMarks;
      } else {
        // Decimal comparison (e.g. 2 decimal places window check)
        return Math.abs(sNum - cNum) < 0.0101 ? posMarks : -negMarks;
      }
    }

    // 2. Single Correct MCQ & True/False
    if (qType === 'mcq_single' || qType === 'true_false' || qType === 'single') {
      const isCorrect = correctList.includes(selectedList[0]);
      return isCorrect ? posMarks : -negMarks;
    }

    // 3. Multiple Correct MCQ
    if (qType === 'mcq_multiple' || qType === 'multiple') {
      const hasIncorrectSelected = selectedList.some(item => !correctList.includes(item));
      
      if (hasIncorrectSelected) {
        if (policy === 'partial_positive') {
          return 0;
        }
        return -negMarks;
      }

      const numSelected = selectedList.length;
      const numCorrect = correctList.length;

      if (numSelected === numCorrect) {
        return posMarks;
      } else if (numSelected < numCorrect && numSelected > 0) {
        if (policy === 'partial_positive' || policy === 'partial_negative') {
          // Standard NTA/JEE Advanced partial marking: +1 mark per correct option selected
          return numSelected; 
        }
        return 0;
      }
      return 0;
    }

    // Fallback string matching
    const isMatch = String(studentAnswer).trim().toLowerCase() === String(question.correct_answer).trim().toLowerCase();
    return isMatch ? posMarks : -negMarks;
  };

  const handleOverrideChange = (qId, value) => {
    setMarkOverrides(prev => ({
      ...prev,
      [qId]: value === '' ? undefined : parseFloat(value) // allow clearing the override
    }));
  };

  const handlePublish = async () => {
    if (!window.confirm("Are you sure you want to publish this result? The student will be able to see their score.")) {
      return;
    }
    
    setPublishing(true);
    try {
      // 1. Calculate final aggregates
      let totalScore = 0;
      let totalMarks = 0;
      let correctCount = 0;
      let wrongCount = 0;
      let unattemptedCount = 0;

      questions.forEach(q => {
        // Assume 'dropped' questions aren't in total marks
        if (q.status !== 'dropped') {
          totalMarks += (q.positive_marks || exam.correct_marks || 4);
        }

        const studentAnswer = submission?.answers?.[q.id];
        const autoMark = calculateAutoMark(q);
        const finalMark = markOverrides[q.id] !== undefined ? markOverrides[q.id] : autoMark;

        totalScore += finalMark;

        if (studentAnswer === undefined || studentAnswer === '') {
          unattemptedCount++;
        } else if (finalMark > 0) {
          correctCount++;
        } else {
          wrongCount++;
        }
      });

      const percentage = totalMarks > 0 ? Math.round((totalScore / totalMarks) * 100) : 0;

      // 2. Update the submission record
      const { error: updateError } = await supabase
        .from('exam_results')
        .update({
          status: 'published',
          total_score: totalScore,
          total_marks: totalMarks,
          percentage: percentage,
          correct_count: correctCount,
          wrong_count: wrongCount,
          unattempted_count: unattemptedCount,
          marks_adjustments: markOverrides,
          published_at: new Date().toISOString()
        })
        .eq('id', submissionId);

      if (updateError) throw updateError;

      alert("Result Published Successfully!");
      navigate('/admin/dashboard');

    } catch (err) {
      console.error("Publish Error:", err);
      alert("Failed to publish result.");
    } finally {
      setPublishing(false);
    }
  };

  const handleResetAttempt = async () => {
    const studentName = student?.full_name || 'Student';
    const examTitle = exam?.title || 'Exam';
    
    if (!window.confirm(`Are you sure you want to RESET the attempt for ${studentName} on "${examTitle}"?\n\nThis will delete their exam submission permanently and let them take the test again.`)) {
      return;
    }
    
    try {
      const { error } = await supabase
        .from('exam_results')
        .delete()
        .eq('id', submissionId);
        
      if (error) throw error;
      alert("Attempt reset successfully. Candidate can now retake this exam.");
      navigate('/admin/dashboard');
    } catch (err) {
      console.error(err);
      alert("Failed to reset attempt: " + err.message);
    }
  };

  const handleToggleAccess = async () => {
    const studentName = student?.full_name || 'Student';
    const examTitle = exam?.title || 'Exam';
    const isBlocking = submission?.status !== 'blocked';
    
    const confirmMessage = isBlocking
      ? `Are you sure you want to REVOKE access for ${studentName} on "${examTitle}"?\n\nThey will not be able to view their scorecard or attempt it again.`
      : `Are you sure you want to RESTORE access for ${studentName} on "${examTitle}"?`;

    if (!window.confirm(confirmMessage)) {
      return;
    }

    try {
      const newStatus = isBlocking ? 'blocked' : 'submitted';
      const { error } = await supabase
        .from('exam_results')
        .update({ status: newStatus })
        .eq('id', submissionId);

      if (error) throw error;
      alert(isBlocking ? "Access revoked successfully." : "Access restored successfully.");
      navigate('/admin/dashboard');
    } catch (err) {
      console.error(err);
      alert("Failed to update access status: " + err.message);
    }
  };

  if (loading) {
    return <div className="p-8 text-center text-lg font-bold text-[#005fa7]">Loading Submission Data...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-600 font-bold">{error}</div>;
  }

  // Calculate live stats for the header
  let liveTotalScore = 0;
  questions.forEach(q => {
    const autoMark = calculateAutoMark(q);
    const finalMark = markOverrides[q.id] !== undefined ? markOverrides[q.id] : autoMark;
    liveTotalScore += finalMark;
  });

  return (
    <div className="min-h-screen bg-gray-50 p-6 font-sans">
      
      {/* Header & Back Button */}
      <div className="max-w-6xl mx-auto mb-6 flex justify-between items-center">
        <div>
          <Link to="/admin/dashboard" className="text-[#005fa7] hover:underline mb-2 inline-block font-semibold">
            &larr; Back to Dashboard
          </Link>
          <h1 className="text-3xl font-bold text-gray-800">Review Submission</h1>
        </div>
        <div className="flex gap-3">
          <button
            onClick={handleResetAttempt}
            className="px-5 py-3 rounded font-bold text-white shadow-md bg-red-600 hover:bg-red-700 transition-colors cursor-pointer text-sm"
          >
            Reset Attempt (Assign Again)
          </button>
          
          {submission.status === 'blocked' ? (
            <button
              onClick={handleToggleAccess}
              className="px-5 py-3 rounded font-bold text-white shadow-md bg-green-600 hover:bg-green-700 transition-colors cursor-pointer text-sm"
            >
              Restore Access
            </button>
          ) : (
            <button
              onClick={handleToggleAccess}
              className="px-5 py-3 rounded font-bold text-white shadow-md bg-amber-500 hover:bg-amber-600 transition-colors cursor-pointer text-sm"
            >
              Revoke Access (Block)
            </button>
          )}

          <button
            onClick={handlePublish}
            disabled={publishing || submission.status === 'published' || submission.status === 'blocked'}
            className={`px-6 py-3 rounded font-bold text-white shadow-md transition-colors text-sm ${
              submission.status === 'published' || submission.status === 'blocked'
                ? 'bg-gray-450 text-gray-200 cursor-not-allowed' 
                : 'bg-blue-600 hover:bg-blue-700 cursor-pointer'
            }`}
          >
            {publishing ? 'Publishing...' : submission.status === 'published' ? 'Already Published' : submission.status === 'blocked' ? 'Access Revoked' : 'Publish Result'}
          </button>
        </div>
      </div>

      {/* Meta Info Cards */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200 border-l-4 border-l-blue-500">
          <p className="text-sm text-gray-500 font-semibold uppercase">Candidate Details</p>
          <p className="font-bold text-lg text-gray-800">{student?.full_name}</p>
          <p className="text-sm text-gray-600">{student?.application_id} | {student?.email}</p>
        </div>
        
        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200 border-l-4 border-l-yellow-500">
          <p className="text-sm text-gray-500 font-semibold uppercase">Exam Details</p>
          <p className="font-bold text-lg text-gray-800">{exam?.title}</p>
          <p className="text-sm text-gray-600">Submitted: {new Date(submission?.submitted_at).toLocaleString()}</p>
        </div>

        <div className="bg-white p-5 rounded-lg shadow-sm border border-gray-200 border-l-4 border-l-green-500">
          <p className="text-sm text-gray-500 font-semibold uppercase">Live Score Preview</p>
          <p className="font-bold text-3xl text-gray-800">{liveTotalScore}</p>
          <p className="text-sm text-gray-600">With manual overrides applied</p>
        </div>
      </div>

      {/* Question Review List */}
      <div className="max-w-6xl mx-auto space-y-6">
        <h2 className="text-xl font-bold text-gray-800 border-b pb-2">Question-by-Question Breakdown</h2>
        
        {questions.map((q, index) => {
          const studentAnswer = submission?.answers?.[q.id];
          const hasAnswered = studentAnswer !== undefined && studentAnswer !== '';
          const autoMark = calculateAutoMark(q);
          const hasOverride = markOverrides[q.id] !== undefined;
          const currentMark = hasOverride ? markOverrides[q.id] : autoMark;

          return (
            <div key={q.id} className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 relative overflow-hidden">
              
              {/* Question Status Indicator Strip */}
              <div className={`absolute left-0 top-0 bottom-0 w-2 ${
                !hasAnswered ? 'bg-gray-300' : currentMark > 0 ? 'bg-green-500' : 'bg-red-500'
              }`}></div>

              <div className="pl-4">
                <div className="flex justify-between items-start mb-4">
                  <div className="font-bold text-lg text-[#005fa7]">Question {index + 1}</div>
                  <div className="text-sm font-semibold text-gray-500 bg-gray-100 px-3 py-1 rounded">
                    Type: {q.question_type} | Max Marks: {q.positive_marks || exam.correct_marks}
                  </div>
                </div>

                <div className="text-gray-800 font-medium mb-4 whitespace-pre-wrap">
                  {q.question_text}
                </div>
                
                {q.image_url && (
                  <img src={q.image_url} alt="Question Graphic" className="max-w-md h-auto mb-4 border rounded" />
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-gray-50 p-4 rounded border border-gray-200 mb-4">
                  <div>
                    <span className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Student's Answer</span>
                    <span className={`font-mono text-base font-bold ${!hasAnswered ? 'text-gray-400 italic' : 'text-gray-800'}`}>
                      {hasAnswered 
                        ? (Array.isArray(studentAnswer) ? studentAnswer.join(', ') : studentAnswer) 
                        : 'NOT ATTEMPTED'}
                    </span>
                  </div>
                  <div>
                    <span className="block text-xs font-bold text-gray-500 uppercase tracking-wide mb-1">Provisional Key</span>
                    <span className="font-mono text-base font-bold text-green-700">
                      {q.correct_answer || 'N/A'}
                    </span>
                  </div>
                </div>

                {/* Marking Override Engine */}
                <div className="flex items-center justify-between bg-blue-50 p-4 rounded border border-blue-200">
                  <div className="flex flex-col">
                    <span className="text-sm font-bold text-blue-900">Auto-Calculated Marks: {autoMark}</span>
                    {hasOverride && <span className="text-xs text-orange-600 font-bold mt-1">⚠️ Manual Override Active</span>}
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <label className="text-sm font-bold text-gray-700">Final Awarded Marks:</label>
                    <input 
                      type="number"
                      step="any"
                      value={markOverrides[q.id] !== undefined ? markOverrides[q.id] : ''}
                      onChange={(e) => handleOverrideChange(q.id, e.target.value)}
                      placeholder={autoMark.toString()}
                      className={`w-24 px-3 py-2 border rounded font-bold focus:outline-none focus:ring-2 focus:ring-blue-500 ${hasOverride ? 'bg-orange-50 border-orange-300 text-orange-700' : 'bg-white border-gray-300'}`}
                    />
                  </div>
                </div>

              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default ReviewSubmission;
