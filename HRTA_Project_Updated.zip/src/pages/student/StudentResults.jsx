import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';

const StudentResults = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [student, setStudent] = useState(null);
  const [results, setResults] = useState([]);
  const [selectedResult, setSelectedResult] = useState(null);

  useEffect(() => {
    const fetchResults = async () => {
      try {
        const userId = sessionStorage.getItem('userId');
        const role = sessionStorage.getItem('role');

        if (!userId || role !== 'student') {
          navigate('/');
          return;
        }

        // Fetch Student
        const { data: studentData, error: studentError } = await supabase
          .from('students')
          .select('*')
          .eq('id', userId)
          .single();

        if (studentError) throw studentError;
        setStudent(studentData);

        // Fetch Published Results with joined Exam details
        const { data: resultsData, error: resultsError } = await supabase
          .from('exam_results')
          .select(`
            *,
            exams (
              title,
              subject,
              exam_type,
              start_datetime,
              correct_marks,
              negative_marks
            )
          `)
          .eq('student_id', userId)
          .eq('status', 'published')
          .order('published_at', { ascending: false });

        if (resultsError) throw resultsError;

        setResults(resultsData || []);
        
        // Auto-select the most recent result if exists
        if (resultsData && resultsData.length > 0) {
          setSelectedResult(resultsData[0]);
        }

      } catch (err) {
        console.error('Error fetching results:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchResults();
  }, [navigate]);

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#f1f4f9] flex items-center justify-center font-sans">
        <div className="text-[#1f497d] font-bold text-lg flex items-center">
          <svg className="animate-spin h-6 w-6 mr-3" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Generating Scorecards...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f1f4f9] font-sans pb-12 print:bg-white print:pb-0">
      
      {/* Hide Sidebar/Nav areas on print via Tailwind print classes */}
      <div className="print:hidden bg-[#1f497d] text-white py-4 px-6 shadow-md border-b-4 border-yellow-500 mb-6">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div>
            <h1 className="text-xl font-bold uppercase tracking-wider">Candidate Scorecards</h1>
            <p className="text-sm font-medium opacity-90">View and download your official results</p>
          </div>
          <button 
            onClick={handlePrint}
            disabled={!selectedResult}
            className="bg-white text-[#1f497d] hover:bg-gray-100 px-5 py-2 rounded font-bold shadow transition-colors flex items-center disabled:opacity-50"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
            </svg>
            Download PDF
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row gap-6 print:block print:p-0">
        
        {/* Left Column: Exam Selection List (Hidden on Print) */}
        <div className="w-full lg:w-1/4 print:hidden space-y-4">
          <div className="bg-white rounded border border-gray-300 shadow-sm overflow-hidden">
            <div className="bg-gray-100 px-4 py-3 border-b border-gray-300 font-bold text-gray-800">
              Evaluated Exams
            </div>
            <div className="max-h-[600px] overflow-y-auto">
              {results.length === 0 ? (
                <div className="p-4 text-center text-sm text-gray-500 font-medium">
                  No published results available.
                </div>
              ) : (
                results.map((res) => (
                  <button
                    key={res.id}
                    onClick={() => setSelectedResult(res)}
                    className={`w-full text-left p-4 border-b border-gray-200 transition-colors ${
                      selectedResult?.id === res.id 
                        ? 'bg-blue-50 border-l-4 border-l-[#1f497d]' 
                        : 'hover:bg-gray-50 bg-white border-l-4 border-l-transparent'
                    }`}
                  >
                    <p className="font-bold text-sm text-[#1f497d] truncate">{res.exams?.title}</p>
                    <p className="text-xs text-gray-500 font-semibold mt-1">Score: {res.total_score} / {res.total_marks}</p>
                    <p className="text-xs text-gray-400 mt-1">{new Date(res.published_at).toLocaleDateString()}</p>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Exact NTA Style Scorecard (Visible on Print) */}
        <div className="w-full lg:w-3/4 print:w-full">
          {!selectedResult ? (
            <div className="bg-white p-12 text-center text-gray-500 border border-gray-300 rounded shadow-sm print:hidden">
              Select an exam from the list to view its scorecard.
            </div>
          ) : (
            <div id="scorecard-print-area" className="bg-white border border-gray-300 rounded shadow-lg p-8 print:shadow-none print:border-none print:p-0">
              
              {/* NTA Scorecard Header */}
              <div className="border-b-2 border-[#005fa7] pb-4 mb-6 text-center relative flex justify-between items-center">
                <img src="/assets/emblem.png" alt="Satyameva Jayate" className="h-20 w-12 object-contain" />
                
                <div className="flex-1 px-4">
                  <h2 className="text-[#005fa7] text-2xl font-black uppercase tracking-wide">Harman Rathi Testing Agency</h2>
                  <p className="text-gray-700 font-bold text-sm mt-1 uppercase">Excellence in Assessment</p>
                  <p className="text-gray-800 font-bold text-lg mt-3 bg-gray-100 py-1 border border-gray-300 inline-block px-6 rounded-full">
                    {selectedResult.exams?.title} - FINAL SCORECARD
                  </p>
                </div>
                
                <img src="/assets/nta_logo.png" alt="NTA Logo" className="h-16 w-auto object-contain" />
              </div>

              {/* Candidate Details Grid */}
              <div className="border border-gray-400 mb-8 rounded overflow-hidden text-sm">
                <table className="w-full text-left">
                  <tbody>
                    <tr className="border-b border-gray-300">
                      <td className="w-1/4 bg-gray-100 p-2 font-bold text-gray-700 border-r border-gray-300">Application Number :</td>
                      <td className="w-1/4 p-2 font-bold border-r border-gray-300">{student?.application_id}</td>
                      <td className="w-1/4 bg-gray-100 p-2 font-bold text-gray-700 border-r border-gray-300">Roll Number :</td>
                      <td className="w-1/4 p-2 font-bold">{student?.application_id.replace('HRTA', 'RL')}</td>
                    </tr>
                    <tr className="border-b border-gray-300">
                      <td className="bg-gray-100 p-2 font-bold text-gray-700 border-r border-gray-300">Candidate's Name :</td>
                      <td className="p-2 font-bold uppercase text-[#1f497d] border-r border-gray-300">{student?.full_name}</td>
                      <td className="bg-gray-100 p-2 font-bold text-gray-700 border-r border-gray-300">Date of Birth :</td>
                      <td className="p-2 font-bold">{student?.date_of_birth}</td>
                    </tr>
                    <tr className="border-b border-gray-300">
                      <td className="bg-gray-100 p-2 font-bold text-gray-700 border-r border-gray-300">Category :</td>
                      <td className="p-2 font-bold border-r border-gray-300">{student?.category || 'General'}</td>
                      <td className="bg-gray-100 p-2 font-bold text-gray-700 border-r border-gray-300">Gender :</td>
                      <td className="p-2 font-bold">Male</td> {/* Adjust if gender is added to DB */}
                    </tr>
                    <tr>
                      <td className="bg-gray-100 p-2 font-bold text-gray-700 border-r border-gray-300">Test Date & Time :</td>
                      <td className="p-2 font-bold border-r border-gray-300" colSpan="3">
                        {new Date(selectedResult.started_at).toLocaleString()}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Score Details Section */}
              <div className="mb-8">
                <div className="bg-[#1f497d] text-white font-bold px-4 py-2 text-center uppercase tracking-wider mb-4 rounded-t">
                  Performance Details
                </div>
                
                <table className="w-full border-collapse border border-gray-400 text-sm">
                  <thead>
                    <tr className="bg-gray-200 text-gray-800 text-center">
                      <th className="border border-gray-400 p-3 font-bold w-1/3">Subject Name</th>
                      <th className="border border-gray-400 p-3 font-bold w-1/3">Total Marks</th>
                      <th className="border border-gray-400 p-3 font-bold w-1/3">Marks Obtained</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="text-center">
                      <td className="border border-gray-400 p-4 font-bold text-[#1f497d]">{selectedResult.exams?.subject || 'General'}</td>
                      <td className="border border-gray-400 p-4 font-bold text-gray-700">{selectedResult.total_marks}</td>
                      <td className="border border-gray-400 p-4 font-black text-xl text-green-700 bg-green-50">{selectedResult.total_score}</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Accuracy Analytics */}
              <div className="flex justify-between gap-4 mb-8 text-center text-sm">
                <div className="flex-1 bg-gray-50 border border-gray-300 p-4 rounded">
                  <p className="font-bold text-gray-500 uppercase text-xs mb-1">Correct Answers</p>
                  <p className="font-black text-2xl text-green-600">{selectedResult.correct_count}</p>
                </div>
                <div className="flex-1 bg-gray-50 border border-gray-300 p-4 rounded">
                  <p className="font-bold text-gray-500 uppercase text-xs mb-1">Incorrect Answers</p>
                  <p className="font-black text-2xl text-red-600">{selectedResult.wrong_count}</p>
                </div>
                <div className="flex-1 bg-gray-50 border border-gray-300 p-4 rounded">
                  <p className="font-bold text-gray-500 uppercase text-xs mb-1">Unattempted</p>
                  <p className="font-black text-2xl text-gray-600">{selectedResult.unattempted_count}</p>
                </div>
                <div className="flex-1 bg-gray-50 border border-gray-300 p-4 rounded">
                  <p className="font-bold text-gray-500 uppercase text-xs mb-1">Accuracy / Rank</p>
                  <p className="font-black text-2xl text-[#1f497d]">{selectedResult.percentage}% / AIR {selectedResult.rank || '-'}</p>
                </div>
              </div>

              {/* Disclaimer / Remarks */}
              <div className="border border-gray-400 p-4 bg-[#f8f9fa] text-xs text-gray-700 leading-relaxed text-justify mb-8 rounded">
                <p className="font-bold mb-2 underline">Note:</p>
                <ol className="list-decimal pl-4 space-y-1">
                  <li>This score card indicates the candidate's performance in the Computer Based Test (CBT) conducted by HRTA.</li>
                  <li>The Total Marks and Subject-wise marks are calculated using the final normalized scoring logic. Final Answer keys are used for evaluation.</li>
                  <li>No grievance with regard to answer key(s) will be entertained after the publication of this scorecard.</li>
                  <li>In case of a tie in the total score, the ranking is resolved based on time taken to complete the examination.</li>
                </ol>
              </div>

              {/* Digital Signature */}
              <div className="flex justify-end mt-12 mb-4">
                <div className="text-center">
                  <div className="w-32 border-b-2 border-gray-400 mb-2 border-dashed"></div>
                  <p className="font-bold text-xs text-gray-800">Senior Director, HRTA</p>
                  <p className="text-[10px] text-gray-500 mt-1">System Generated - {new Date().toLocaleDateString()}</p>
                </div>
              </div>

            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentResults;
