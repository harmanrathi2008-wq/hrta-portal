import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { Folder, File, ExternalLink } from 'lucide-react'

export default function StudentMaterials() {
  const [materials, setMaterials] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadMaterials()
  }, [])

  const loadMaterials = async () => {
    const { data } = await supabase
      .from('study_materials')
      .select('*')
      .order('created_at', { ascending: false })
    
    setMaterials(data || [])
    setLoading(false)
  }

  if (loading) {
    return <div className="text-center py-12">Loading study materials...</div>
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold">Study Materials</h1>

      {materials.length === 0 ? (
        <div className="glass-card rounded-xl p-12 text-center">
          <Folder className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">No study materials available yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
          {materials.map((material) => (
            <div
              key={material.id}
              className="glass-card rounded-xl p-4 text-center hover:neon-glow transition-all cursor-pointer"
              onClick={() => window.open(material.google_drive_link, '_blank')}
            >
              <File className="w-10 h-10 mx-auto mb-2 text-primary" />
              <p className="text-sm font-medium truncate">{material.title}</p>
              <p className="text-xs text-muted-foreground mt-1">{material.subject}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
